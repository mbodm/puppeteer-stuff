import { cheerio } from "https://deno.land/x/cheerio@1.0.7/mod.ts";
import { encodeUrl } from "https://deno.land/x/encodeurl/mod.ts";

const encodedUrl = encodeUrl(
  "https://kami4ka.github.io/dynamic-website-example/",
);

export async function execute() {
  try {
    const response = await fetch(
      "https://api.scrapingant.com/v1/general?url=" + encodedUrl,
      {
        method: "GET",
        headers: {
          "x-api-key": "<YOUR_API_TOKEN>",
        },
      },
    );

    const data = await response.json();

    const $ = cheerio.load(data.content);

    const pageText = $("div").text();

    console.log(pageText);
  } catch (error) {
    console.log(error);
  }
}
