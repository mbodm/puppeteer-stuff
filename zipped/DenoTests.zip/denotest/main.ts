// import { launch } from "jsr:@astral/astral";
// import * as cheerio from "./cheerio.ts";
// import * as fuzz from "./playwright.ts";
import * as pupp from "./pupeteer.ts";

if (import.meta.main) {
  await pupp.execute();

  // const browser = await launch();
  // const page = await browser.newPage(
  //   "https://curseforge.com/wow/addons/details",
  // );
  // const value = await page.evaluate(() => {
  //   return btoa(
  //     unescape(
  //       encodeURIComponent(
  //         document.querySelector("script#__NEXT_DATA__")?.innerHTML ?? "",
  //       ),
  //     ),
  //   );
  // });

  // //console.log(value);
  // const url = serializeAddonPageJson(value);

  // /*
  // const json =
  //   "btoa(unescape(encodeURIComponent(document.querySelector('script#__NEXT_DATA__')?.innerHTML ?? '')))";
  // serializeAddonPageJson(json);
  // */
  // const screenshot = await page.screenshot();
  // Deno.writeFileSync("screenshot.png", screenshot);

  // console.log("go");
  // const downloadPage = await browser.newPage(url);
  // console.log("end");

  // await browser.close();
}

function serializeAddonPageJson(json: string): string {
  // Curse addon page JSON format:
  // props
  //   pageProps
  //     project
  //       id             --> Short number for download URL       Example --> 3358
  //       mainFile
  //         fileName     --> The name of the zip file            Example --> "DBM-10.0.35.zip"
  //         fileSize     --> The size of the zip file            Example --> 123456789
  //         id           --> Long number for download URL        Example --> 4485146
  //       name           --> Useful name of the addon            Example --> "Deadly Boss Mods (DBM)"
  //       slug           --> Slug name of the addon              Example --> "deadly-boss-mods"

  const encodedJson = atob(json);
  const root = JSON.parse(encodedJson);
  const project = root.props.pageProps.project;
  const result = {
    projectId: project.id as number,
    projectName: project.name as string,
    projectSlug: project.slug as string,
    fileId: project.mainFile.id as number,
    fileName: project.mainFile.fileName as string,
    fileSize: project.mainFile.fileLength as number,
    downloadUrl: "" as string,
  };
  result.downloadUrl = buildInitialDownloadUrl(result.projectId, result.fileId);
  console.log(result);
  return result.downloadUrl;
}

function buildInitialDownloadUrl(projectId: number, fileId: number): string {
  return `https://www.curseforge.com/api/v1/mods/${projectId}/files/${fileId}/download`;
}
