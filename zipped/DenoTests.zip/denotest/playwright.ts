import { chromium } from "npm:playwright";

export async function execute() {

    console.log("logs");
    const browser = await chromium.launch();
    console.log("doesn’t log");
}
