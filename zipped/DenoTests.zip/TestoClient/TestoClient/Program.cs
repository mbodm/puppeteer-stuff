﻿using var httpClient = new HttpClient();
string[] addons = [
    "https://www.curseforge.com/wow/addons/raiderio",
    "https://www.curseforge.com/wow/addons/recount",
    "https://www.curseforge.com/wow/addons/details",
    "https://www.curseforge.com/wow/addons/tomtom",
        "https://www.curseforge.com/wow/addons/raiderio",
    "https://www.curseforge.com/wow/addons/recount",
    "https://www.curseforge.com/wow/addons/details",
    "https://www.curseforge.com/wow/addons/tomtom",

        "https://www.curseforge.com/wow/addons/raiderio",
    "https://www.curseforge.com/wow/addons/recount",
    "https://www.curseforge.com/wow/addons/details",
    "https://www.curseforge.com/wow/addons/tomtom",

        "https://www.curseforge.com/wow/addons/raiderio",
    "https://www.curseforge.com/wow/addons/recount",
    "https://www.curseforge.com/wow/addons/details",
    "https://www.curseforge.com/wow/addons/tomtom",


];
foreach (var addon in addons)
{
    var url = "http://localhost:8080/json?target=" + addon;
    var response = await httpClient.GetAsync(url);
    if (response.IsSuccessStatusCode)
    {
        var content = await response.Content.ReadAsStringAsync();
        Console.WriteLine(content);
    }
}
Console.WriteLine("Have a nice day.");
