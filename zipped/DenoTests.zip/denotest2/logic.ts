import * as logger from "./logger.ts";
import * as browser from "./browser.ts";
import { Page } from "puppeteer";

export type LogicResult = {
    error: string | null;
    result: object | null;
};

export async function run(url: string): Promise<LogicResult> {
    logger.log('logic called');
    const page = browser.getPage();
    if (!page) {
        logger.log('no page');
        return createResult('Could not get Puppeteer Browser instance (initialization is missing maybe).');
    }
    logger.log('got page');


    logger.log('MBOODM >>>>>>>>>>>>>');
    logger.log('target is: ' + url);
    await page.goto(url, {
        //waitUntil: "domcontentloaded",
        waitUntil: "load",
        timeout: 30000,
    });
    logger.log('MBOODM <<<<<<<<<<<<<<<<<');
    return createResult('kein error', { message: 'page erreicht'});
    






    const addons = [
        "raiderio",
        "details",
        "tomtom",
        "recount",
        "handynotes",
    ];
    const results: object[] = [];

    for (const addon of addons) {
        const fuzz = await GetAddonScriptContent(page, addon);
        if (fuzz.error !== null) {
            return fuzz;
        }
        let value = '';
        if (fuzz?.result !== null) {
            value = (fuzz.result as any).value;
        }
        logger.log('got value');
        const o = getO(value) ?? {};
        results.push(o);
    }

    logger.log('created result and exit');
    return createResult(undefined, results);
}

function createResult(errorMessage?: string, successObject?: object): LogicResult {
    const error = errorMessage ? errorMessage : null;
    const result = successObject ? successObject : null;
    return {
        error,
        result
    }
}

function getO(value: string): object | null {
    const json = JSON.parse(value);
    const project = json?.props?.pageProps?.project;
    if (!project) {
        logger.log('no JSON project');
        //return createResult('Could not find "project" in JSON data.');
        return null;
    }
    const file = project.mainFile;
    if (!file) {
        logger.log('no JSON mainFile');
        //return createResult('Could not find the project\'s "mainFile" in JSON data.');
        return null;
    }
    const projectId = project.id ?? 'NOTFOUNDERROR';
    const fileId = file.id ?? 'NOTFOUNDERROR';
    const downloadUrl = `https://www.curseforge.com/api/v1/mods/${projectId}/files/${fileId}/download`;
    logger.log('combined download url');
    const result = {
        projectId,
        projectName: project.name ?? 'NOTFOUNDERROR',
        projectSlug: project.slug ?? 'NOTFOUNDERROR',
        fileId,
        fileName: file.fileName ?? 'NOTFOUNDERROR',
        fileLength: file.fileLength ?? 'NOTFOUNDERROR',
        gameVersion: file.primaryGameVersion ?? 'NOTFOUNDERROR',
        downloadUrl
    };
    return result;
}

async function GetAddonScriptContent(page: Page, addon: string): Promise<LogicResult> {
    const url = `http://www.curseforge.com/wow/addons/${addon}`;
    await page.goto(url, {
        //waitUntil: "domcontentloaded",
        waitUntil: "load",
        timeout: 30000,
    });
    logger.log('navigated to url');
    /*
    const source = await page.content();
    if (!source) {
        logger.log('empty content');
        return createResult('Received Curse HTML source was empty.');
    }
    logger.log('received content');
    */
    const element = await page.$("script#__NEXT_DATA__");
    if (!element) {
        logger.log('no element');
        return createResult('Received Curse HTML source not contained "__NEXT_DATA__" element.');
    }
    logger.log('found element');
    const value = await page.evaluate((el) => el.textContent, element);
    if (!value) {
        logger.log('empty value');
        return createResult('Could not get data from received Curse HTML "__NEXT_DATA__" element.');
    }
    return createResult(undefined, { value });
}
