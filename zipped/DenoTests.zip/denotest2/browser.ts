import { Browser, Page } from "puppeteer";
import * as browserless from "./browserless.ts";
import * as browserlocal from "./browserlocal.ts";
import * as logger from "./logger.ts";

let page: Page | null | undefined = null;
let browser: Browser | null | undefined = null;

const useLocal: boolean = true;

export async function init(): Promise<boolean> {
    if (!browser) {
        try {
            browser = useLocal ? await browserlocal.getBrowser() : await browserless.getBrowser();
        }
        catch {
            logger.log('puppeteer browser initialization exception occurred');
            browser = null;
            return false;
        }
    }
    if (!page) {
        try {
            page = await browser.newPage();
            await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
            await page.setExtraHTTPHeaders({ 'Accept-Language': 'en' });
        }
        catch {
            logger.log('puppeteer page initialization exception occurred');
            page = null;
            return false;
        }
    }
    return true;
}

export async function deinit(): Promise<boolean> {
    if (page) {
        try {
            await page.close();
            page = null;
        }
        catch {
            logger.log('puppeteer page de-initialization exception occurred');
            return false;
        }
    }
    if (browser) {
        try {
            await browser.close();
            browser = null;
        }
        catch {
            logger.log('puppeteer browser de-initialization exception occurred');
            return false;
        }
    }
    return true;
}

export function getPage(): Page | null {
    return page ? page : null;
}