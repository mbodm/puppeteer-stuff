import puppeteer, { Browser } from "npm:puppeteer";

export async function getBrowser(): Promise<Browser> {
    const browser = await puppeteer.launch({headless: false});
    return browser;
}