import { listenAndServe } from "https://deno.land/std@0.111.0/http/server.ts";
import * as logger from "./logger.ts";
import * as browser from "./browser.ts";
import * as logic from "./logic.ts";

async function handleRequest(request: any) {
  const { pathname } = new URL(request.url);

  // Respond with HTML
  if (pathname.startsWith("/html")) {
    const html = `<html>
      <p><b>Message:</b> Hello from Deno Deploy.</p>
      </html>`;

    return new Response(html, {
      headers: {
        // The interpretation of the body of the response by the client depends
        // on the 'content-type' header.
        // The "text/html" part implies to the client that the content is HTML
        // and the "charset=UTF-8" part implies to the client that the content
        // is encoded using UTF-8.
        "content-type": "text/html; charset=UTF-8",
      },
    });
  }

  if (pathname.startsWith("/init")) {
    const success = await browser.init();
    const json = JSON.stringify({ success });
    return new Response(json, {
      headers: {
        "content-type": "application/json; charset=UTF-8",
      },
    });
  }

  if (pathname.startsWith("/deinit")) {
    const success = await browser.deinit();
    const json = JSON.stringify({ success });
    return new Response(json, {
      headers: {
        "content-type": "application/json; charset=UTF-8",
      },
    });
  }

  if (pathname.startsWith("/json")) {
    logger.log("main -> received request - starting logic now");
    const url = new URL(request.url);
    let target = 'https://www.curseforge.com/wow/addons/raiderio';
    if (url.searchParams.has('target')) {
      target = url.searchParams.get('target') ?? 'noparamerror';
    }
    const result = await logic.run(target);
    logger.log("main -> logic ended - returning response now");
    const json = JSON.stringify(result);
    return new Response(json, {
      headers: {
        "content-type": "application/json; charset=UTF-8",
      },
    });
  }

  return new Response(
    `<body
      align="center"
      style="font-family: Avenir, Helvetica, Arial, sans-serif; font-size: 1.5rem;"
    >
      <h1>Available endpoints:</h1>
      <p>
        <a href="/init">/init</a> -> Initialize logic
      </p>
      <p>
        <a href="/deinit">/deinit</a> -> De-Initialize logic
      </p>
      <p>
        <a href="/json">/json</a> -> Get JSON
      </p>
    </body>`,
    {
      headers: {
        "content-type": "text/html; charset=UTF-8",
      },
    },
  );
}

console.log("Listening on http://localhost:8080");
await listenAndServe(":8080", handleRequest);
